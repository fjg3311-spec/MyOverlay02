plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.kaewkung.myoverlay"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.kaewkung.myoverlay"
        minSdk = 26
        targetSdk = 34
        versionCode = 4
        versionName = "1.2"
    }

    // ใช้ keystore คงที่ เพื่อให้อัปเดตแอปทับของเดิมได้ (ไม่ต้องลบแล้วลงใหม่)
    val ks = file("debug.keystore")
    if (ks.exists()) {
        signingConfigs {
            getByName("debug") {
                storeFile = ks
                storePassword = "android"
                keyAlias = "androiddebugkey"
                keyPassword = "android"
            }
        }
    }

    buildTypes {
        release { isMinifyEnabled = false }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
