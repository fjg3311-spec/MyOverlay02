package com.kaewkung.myoverlay

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.ImageDecoder
import android.graphics.PixelFormat
import android.graphics.drawable.AnimatedImageDrawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.Icon
import android.hardware.display.DisplayManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.util.DisplayMetrics
import android.util.TypedValue
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.RenderProcessGoneDetail
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.max

/** เฟรมที่ดักการสัมผัสไว้เองตอนอยู่ในโหมดแก้ไข (ไม่ให้ WebView แย่ง touch) */
class EditFrame(c: Context) : FrameLayout(c) {
    var editing = false
    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean = editing || super.onInterceptTouchEvent(ev)
}

class OverlayService : Service() {

    companion object {
        const val A_START = "com.kaewkung.myoverlay.START"
        const val A_STOP = "com.kaewkung.myoverlay.STOP"
        const val A_EDIT = "com.kaewkung.myoverlay.EDIT"
        const val A_LOCK = "com.kaewkung.myoverlay.LOCK"
        const val A_RELOAD = "com.kaewkung.myoverlay.RELOAD"
        const val A_REFRESH = "com.kaewkung.myoverlay.REFRESH"
        private const val CHANNEL = "my_overlay_channel"
        private const val NID = 7

        @Volatile
        var running = false

        @Volatile
        private var instance: OverlayService? = null

        /** ปรับความทึบรวมสดๆ โดยไม่ต้องโหลดเว็บซ้ำ */
        fun applyAlpha() {
            instance?.updateAlpha()
        }

        fun send(c: Context, action: String) {
            val i = Intent(c, OverlayService::class.java).setAction(action)
            try {
                if (action == A_START) c.startForegroundService(i) else c.startService(i)
            } catch (e: Exception) {
                c.toast("สั่งงาน Overlay ไม่สำเร็จ")
            }
        }

        fun refresh(c: Context) {
            if (running) send(c, A_REFRESH)
        }
    }

    private class Host(
        val layer: Layer,
        val root: EditFrame,
        val handle: TextView,
        val web: WebView?,
        val content: View,
        val imageView: ImageView?,
        val lp: WindowManager.LayoutParams
    )

    private lateinit var wm: WindowManager
    private lateinit var dm: DisplayManager
    private val handler = Handler(Looper.getMainLooper())
    private val hosts = LinkedHashMap<String, Host>()
    private var toolbar: View? = null
    private var editing = false
    private var listening = false

    private val displayListener = object : DisplayManager.DisplayListener {
        override fun onDisplayAdded(displayId: Int) {}
        override fun onDisplayRemoved(displayId: Int) {}
        override fun onDisplayChanged(displayId: Int) {
            relayoutAll()
        }
    }

    private val BASE_FLAGS = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
        WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
        WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN

    private val minPx get() = dp(80)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        dm = getSystemService(DISPLAY_SERVICE) as DisplayManager
        val ch = NotificationChannel(CHANNEL, "My Overlay", NotificationManager.IMPORTANCE_LOW)
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(ch)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action
        if (action == A_START) {
            editing = false
            startFg()
            if (!Settings.canDrawOverlays(this)) {
                toast("ยังไม่ได้อนุญาตแสดงทับแอปอื่น")
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return START_NOT_STICKY
            }
            running = true
            if (!listening) {
                dm.registerDisplayListener(displayListener, handler)
                listening = true
            }
            rebuildAll()
            return START_NOT_STICKY
        }
        if (!running) {
            stopSelf()
            return START_NOT_STICKY
        }
        when (action) {
            A_STOP -> shutdown()
            A_EDIT -> setEditing(true)
            A_LOCK -> setEditing(false)
            A_RELOAD, A_REFRESH -> rebuildAll()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        removeAll()
        hideToolbar()
        running = false
        instance = null
        if (listening) {
            try { dm.unregisterDisplayListener(displayListener) } catch (e: Exception) {}
            listening = false
        }
        super.onDestroy()
    }

    // ---------- แจ้งเตือน ----------

    private fun startFg() {
        val n = buildNotification()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NID, n)
        }
    }

    private fun updateNotification() {
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(NID, buildNotification())
    }

    private fun buildNotification(): Notification {
        fun pi(action: String, code: Int): PendingIntent = PendingIntent.getService(
            this, code, Intent(this, OverlayService::class.java).setAction(action),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        fun act(label: String, action: String, code: Int): Notification.Action =
            Notification.Action.Builder(Icon.createWithResource(this, R.drawable.ic_stat), label, pi(action, code)).build()

        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val b = Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("My Overlay")
            .setContentText(
                if (editing) "โหมดแก้ไข • ลาก/ย่อขยาย แล้วกด ✓ ล็อก"
                else "กำลังแสดง • กดทะลุอยู่"
            )
            .setContentIntent(open)
            .setOngoing(true)
        if (Build.VERSION.SDK_INT >= 31) {
            b.setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE)
        }
        if (editing) b.addAction(act("✓ ล็อก", A_LOCK, 1)) else b.addAction(act("✎ แก้ไข", A_EDIT, 2))
        b.addAction(act("↻ โหลดซ้ำ", A_RELOAD, 3))
        b.addAction(act("■ หยุด", A_STOP, 4))
        return b.build()
    }

    // ---------- จัดการหน้าต่างลอย ----------

    @Suppress("DEPRECATION")
    private fun screenSize(): Pair<Int, Int> {
        val m = DisplayMetrics()
        dm.getDisplay(Display.DEFAULT_DISPLAY).getRealMetrics(m)
        return Pair(m.widthPixels, m.heightPixels)
    }

    private fun isLandscape(): Boolean {
        val (w, h) = screenSize()
        return w > h
    }

    private fun rebuildAll() {
        removeAll()
        val layers = Store.load(this).filter { it.enabled }
        for (l in layers) {
            try {
                addHost(l)
            } catch (e: Exception) {
                toast("แสดงเลเยอร์ไม่สำเร็จ: ${l.name}")
            }
        }
        if (layers.isEmpty()) toast("ยังไม่มีเลเยอร์ที่เปิดอยู่")
        if (editing) showToolbar()
        updateNotification()
    }

    private fun removeAll() {
        for (h in hosts.values) {
            try { wm.removeViewImmediate(h.root) } catch (e: Exception) {}
            h.web?.let { w ->
                w.stopLoading()
                (w.parent as? ViewGroup)?.removeView(w)
                w.destroy()
            }
        }
        hosts.clear()
    }

    private fun addHost(l: Layer) {
        val frame = EditFrame(this)
        var web: WebView? = null
        var imageView: ImageView? = null
        val content: View = when (l.kind) {
            Kind.WEB -> makeWeb(l.url).also { web = it }
            Kind.IMAGE -> makeImage(l.uri).also { imageView = it.second }.first
            Kind.TEXT -> makeText(l)
        }
        if (l.kind == Kind.IMAGE) {
            // Keep the black backing fully opaque. Apply opacity ONLY to image pixels,
            // otherwise the game becomes visible through transparent/faded areas.
            frame.alpha = 1f
            imageView?.alpha = alphaOf(l)
        } else {
            frame.alpha = alphaOf(l)
        }
        frame.addView(content, FrameLayout.LayoutParams(MATCH, MATCH))

        val handle = TextView(this).apply {
            text = "◢"
            textSize = 18f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = roundBg(C.ACCENT, dp(8).toFloat())
            visibility = View.GONE
        }
        frame.addView(handle, FrameLayout.LayoutParams(dp(40), dp(40), Gravity.BOTTOM or Gravity.END))

        val lp = WindowManager.LayoutParams(
            0, 0,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            BASE_FLAGS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START

        val h = Host(l, frame, handle, web, content, imageView, lp)
        applyBox(h)
        styleHost(h)
        attachTouch(h)
        wm.addView(frame, lp)
        hosts[l.id] = h
    }

    private fun applyBox(h: Host) {
        val (sw, sh) = screenSize()
        val b = if (sw > sh) h.layer.landscape else h.layer.portrait
        h.lp.x = (b.x * sw).toInt()
        h.lp.y = (b.y * sh).toInt()
        h.lp.width = max(minPx, (b.w * sw).toInt())
        h.lp.height = max(minPx, (b.h * sh).toInt())
    }

    /** ความทึบจริง = ความทึบเลเยอร์ × ความทึบรวม */
    private fun alphaOf(l: Layer): Float = (l.opacity / 100f) * (Store.master(this) / 100f)

    fun updateAlpha() {
        for (h in hosts.values) {
            val a = alphaOf(h.layer)
            if (h.layer.kind == Kind.IMAGE) {
                // Keep the opaque black backing independent from image opacity.
                h.root.alpha = 1f
                h.imageView?.alpha = a
            } else {
                h.root.alpha = a
            }
        }
    }

    private fun relayoutAll() {
        for (h in hosts.values) {
            applyBox(h)
            if (h.root.isAttachedToWindow) wm.updateViewLayout(h.root, h.lp)
        }
    }

    private fun styleHost(h: Host) {
        h.root.editing = editing
        h.handle.visibility = if (editing) View.VISIBLE else View.GONE
        h.root.foreground = if (editing) {
            GradientDrawable().apply {
                setColor(Color.TRANSPARENT)
                setStroke(dp(2), C.ACCENT, dp(8).toFloat(), dp(6).toFloat())
                cornerRadius = dp(6).toFloat()
            }
        } else null
        h.root.setBackgroundColor(Color.TRANSPARENT)
        h.lp.flags = if (editing) BASE_FLAGS else BASE_FLAGS or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        if (h.root.isAttachedToWindow) wm.updateViewLayout(h.root, h.lp)
    }

    private fun setEditing(v: Boolean) {
        editing = v
        for (h in hosts.values) styleHost(h)
        if (v) showToolbar() else hideToolbar()
        updateNotification()
    }

    private fun attachTouch(h: Host) {
        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        var startW = 0
        var startH = 0
        var resizing = false
        h.root.setOnTouchListener { v, e ->
            if (!editing) {
                false
            } else {
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        downX = e.rawX
                        downY = e.rawY
                        startX = h.lp.x
                        startY = h.lp.y
                        startW = h.lp.width
                        startH = h.lp.height
                        resizing = e.x > v.width - dp(48) && e.y > v.height - dp(48)
                        true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (e.rawX - downX).toInt()
                        val dy = (e.rawY - downY).toInt()
                        val (sw, sh) = screenSize()
                        if (resizing) {
                            h.lp.width = max(minPx, startW + dx)
                            h.lp.height = max(minPx, startH + dy)
                        } else {
                            h.lp.x = (startX + dx).coerceIn(-(startW - dp(48)), sw - dp(48))
                            h.lp.y = (startY + dy).coerceIn(0, sh - dp(48))
                        }
                        wm.updateViewLayout(h.root, h.lp)
                        true
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        saveBox(h)
                        true
                    }
                    else -> true
                }
            }
        }
    }

    private fun saveBox(h: Host) {
        val (sw, sh) = screenSize()
        val land = sw > sh
        val box = Box(
            h.lp.x / sw.toFloat(), h.lp.y / sh.toFloat(),
            h.lp.width / sw.toFloat(), h.lp.height / sh.toFloat()
        )
        if (land) h.layer.landscape = box else h.layer.portrait = box
        val list = Store.load(this)
        list.find { it.id == h.layer.id }?.let { if (land) it.landscape = box else it.portrait = box }
        Store.save(this, list)
    }

    // ---------- แถบควบคุมตอนแก้ไข ----------

    private fun showToolbar() {
        hideToolbar()
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(6), dp(8), dp(6))
            background = roundBg(C.CARD, dp(26).toFloat(), C.ACCENT, dp(2))
        }
        bar.addView(pill("✓ ล็อก", C.ACCENT) { setEditing(false) })
        bar.addView(
            pill("■ หยุด", C.DANGER) { shutdown() },
            LinearLayout.LayoutParams(WRAP, WRAP).apply { leftMargin = dp(8) }
        )
        val lp = WindowManager.LayoutParams(
            WRAP, WRAP,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        lp.y = dp(48)
        try {
            wm.addView(bar, lp)
            toolbar = bar
        } catch (e: Exception) {
            toolbar = null
        }
    }

    private fun hideToolbar() {
        toolbar?.let {
            try { wm.removeViewImmediate(it) } catch (e: Exception) {}
        }
        toolbar = null
    }

    private fun shutdown() {
        removeAll()
        hideToolbar()
        running = false
        if (listening) {
            try { dm.unregisterDisplayListener(displayListener) } catch (e: Exception) {}
            listening = false
        }
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    // ---------- สร้างเนื้อหาของแต่ละเลเยอร์ ----------

    @SuppressLint("SetJavaScriptEnabled")
    private fun makeWeb(url: String): WebView {
        val w = WebView(this)
        w.setBackgroundColor(Color.TRANSPARENT)
        w.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = false
            allowContentAccess = false
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            useWideViewPort = true
            loadWithOverviewMode = true
        }
        w.webViewClient = object : WebViewClient() {
            // อนุญาตเฉพาะการเปิดหน้าแบบ https
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean =
                !request.url.toString().startsWith("https://")

            override fun onRenderProcessGone(view: WebView, detail: RenderProcessGoneDetail): Boolean {
                handler.post { if (running) rebuildAll() }
                return true
            }
        }
        w.loadUrl(url)
        return w
    }

    private fun makeImage(uriStr: String): Pair<View, ImageView?> {
        // The backing stays 100% opaque; only the ImageView itself receives alpha.
        val backing = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
        }
        var imageView: ImageView? = null
        try {
            val uri = Uri.parse(uriStr)
            val iv = ImageView(this).apply {
                setBackgroundColor(Color.TRANSPARENT)
                scaleType = ImageView.ScaleType.FIT_CENTER
            }
            imageView = iv
            if (Build.VERSION.SDK_INT >= 28) {
                val src = ImageDecoder.createSource(contentResolver, uri)
                val d = ImageDecoder.decodeDrawable(src) { dec, info, _ ->
                    val m = max(info.size.width, info.size.height)
                    if (m > 2048) dec.setTargetSampleSize(m / 2048 + 1)
                }
                iv.setImageDrawable(d)
                if (d is AnimatedImageDrawable) {
                    d.repeatCount = AnimatedImageDrawable.REPEAT_INFINITE
                    d.start()
                }
            } else {
                val bmp = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
                    ?: throw IllegalStateException("decode failed")
                iv.setImageBitmap(bmp)
            }
            backing.addView(iv, FrameLayout.LayoutParams(MATCH, MATCH))
        } catch (e: Throwable) {
            backing.addView(
                tv("⚠ เปิดรูปไม่ได้\nเลือกไฟล์ใหม่ในแอป", 13f, Color.WHITE).apply {
                    gravity = Gravity.CENTER
                }, FrameLayout.LayoutParams(MATCH, MATCH)
            )
        }
        return Pair(backing, imageView)
    }

    private fun makeText(l: Layer): View {
        val color = try { Color.parseColor(l.textColor) } catch (e: Exception) { Color.WHITE }
        return TextView(this).apply {
            text = l.text
            setTextSize(TypedValue.COMPLEX_UNIT_SP, l.textSize.toFloat())
            setTextColor(color)
            gravity = Gravity.CENTER
            setShadowLayer(4f, 0f, 2f, Color.argb(170, 0, 0, 0))
        }
    }
}
