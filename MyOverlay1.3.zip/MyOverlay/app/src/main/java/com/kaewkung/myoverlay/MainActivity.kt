package com.kaewkung.myoverlay

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var root: LinearLayout
    private var layers: List<Layer> = emptyList()
    private var pendingImageId: String? = null

    private val reqImage = 11
    private val reqNotif = 12
    private val dialogTheme = android.R.style.Theme_DeviceDefault_Dialog_Alert

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val scroll = ScrollView(this).apply {
            setBackgroundColor(C.BG)
            isFillViewport = true
        }
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(28), dp(20), dp(40))
        }
        scroll.addView(root, ViewGroup.LayoutParams(MATCH, WRAP))
        setContentView(scroll)

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), reqNotif)
        }
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    // ---------- เปลี่ยนข้อมูล: โหลด → แก้ → บันทึก → สั่ง service รีเฟรช ----------

    private fun mutate(rerender: Boolean = true, block: (MutableList<Layer>) -> Unit) {
        val list = Store.load(this)
        block(list)
        Store.save(this, list)
        layers = list
        OverlayService.refresh(this)
        if (rerender) render()
    }

    // ---------- วาดหน้าจอ ----------

    private fun render() {
        layers = Store.load(this)
        root.removeAllViews()
        val perm = Settings.canDrawOverlays(this)
        val running = OverlayService.running

        renderHeader()
        renderStatus(perm, running)
        renderMaster()
        renderLayers()
        renderAbout()
    }

    private fun renderHeader() {
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        head.addView(AvatarView(this), LinearLayout.LayoutParams(dp(68), dp(68)))
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), 0, 0, 0)
        }
        col.addView(tv("My Overlay", 27f, C.TEXT, true))
        col.addView(tv("by kaew_kung", 14f, C.CYAN, true), lp(topDp = 2))
        col.addView(tv("วิดเจ็ตลอยทับเกมตอนไลฟ์", 12f, C.SUB), lp(topDp = 2))
        head.addView(col)
        root.addView(head)
    }

    private fun renderStatus(perm: Boolean, running: Boolean) {
        val card = card()
        root.addView(card, lp(topDp = 22))

        val (label, color) = when {
            !perm -> "ต้องอนุญาตหน้าต่างลอยก่อน" to C.WARN
            running -> "Overlay กำลังทำงาน" to C.OK
            else -> "พร้อมใช้งาน" to C.CYAN
        }
        card.addView(tv("● $label", 17f, color, true))
        val sub = when {
            !perm -> "แอปต้องได้รับสิทธิ์ \"แสดงทับแอปอื่น\" จึงจะลอยบนเกมได้"
            running -> "กด ✎ แก้ไขตำแหน่ง เพื่อลาก/ย่อขยาย แล้วกด ✓ ล็อก"
            else -> "เปิดเลเยอร์ที่ต้องการ แล้วกดเริ่ม"
        }
        card.addView(tv(sub, 13f, C.SUB), lp(topDp = 4))

        if (!perm) {
            card.addView(pill("อนุญาตแสดงทับแอปอื่น", C.ACCENT) {
                try {
                    startActivity(
                        Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                    )
                } catch (e: Exception) {
                    toast("เปิดหน้าตั้งค่าไม่ได้")
                }
            }, lp(topDp = 14))
        } else if (!running) {
            card.addView(pill("▶  เริ่ม Overlay", C.ACCENT) { startOverlay() }, lp(topDp = 14))
        } else {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            row.addView(
                pill("✎ แก้ไขตำแหน่ง", C.ACCENT) {
                    OverlayService.send(this, OverlayService.A_EDIT)
                    toast("ลาก = ย้าย • ลากมุม ◢ = ย่อขยาย")
                },
                LinearLayout.LayoutParams(0, WRAP, 1f)
            )
            row.addView(
                pill("↻ โหลดซ้ำ", C.CARD2) { OverlayService.send(this, OverlayService.A_RELOAD) },
                LinearLayout.LayoutParams(0, WRAP, 1f).apply { leftMargin = dp(8) }
            )
            card.addView(row, lp(topDp = 14))
            card.addView(pill("■ หยุด Overlay", C.DANGER) {
                OverlayService.send(this, OverlayService.A_STOP)
                root.postDelayed({ render() }, 500)
            }, lp(topDp = 8))
        }
    }

    private fun renderMaster() {
        val card = card()
        root.addView(card, lp(topDp = 14))
        val cur = Store.master(this)
        val lab = tv("ความทึบ Overlay: $cur%", 15f, C.TEXT, true)
        card.addView(lab)
        card.addView(
            tv("ปรับได้ 10–100% • 100% = ทึบเต็มที่ มองทะลุเห็นพื้นหลังไม่ได้", 12f, C.SUB),
            lp(topDp = 2)
        )
        val seek = SeekBar(this).apply {
            max = 90
            progress = cur - 10
            progressTintList = ColorStateList.valueOf(C.CYAN)
            thumbTintList = ColorStateList.valueOf(C.CYAN)
        }
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                lab.text = "ความทึบ Overlay: ${p + 10}%"
                if (fromUser) {
                    Store.setMaster(this@MainActivity, p + 10)
                    OverlayService.applyAlpha()
                }
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        card.addView(seek, lp(topDp = 8))
    }

    private fun startOverlay() {
        if (layers.none { it.enabled }) {
            toast("เปิดเลเยอร์อย่างน้อย 1 รายการก่อน")
            return
        }
        OverlayService.send(this, OverlayService.A_START)
        toast("เริ่มแล้ว • กด ✎ แก้ไขตำแหน่ง เพื่อจัดวาง")
        root.postDelayed({ render() }, 500)
    }

    private fun renderLayers() {
        root.addView(section("เลเยอร์ (${layers.size}/$MAX_LAYERS)"), lp(topDp = 26))
        if (layers.isEmpty()) {
            root.addView(tv("ยังไม่มีเลเยอร์ • กดเพิ่มด้านล่างเพื่อเริ่มต้น", 13f, C.SUB), lp(topDp = 10))
        } else {
            layers.forEach { root.addView(layerRow(it), lp(topDp = 10)) }
        }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(pill("＋ เว็บ", C.CARD2) { addLayer(Kind.WEB) }, LinearLayout.LayoutParams(0, WRAP, 1f))
        row.addView(
            pill("＋ รูป/GIF", C.CARD2) { addLayer(Kind.IMAGE) },
            LinearLayout.LayoutParams(0, WRAP, 1f).apply { leftMargin = dp(8) }
        )
        row.addView(
            pill("＋ ข้อความ", C.CARD2) { addLayer(Kind.TEXT) },
            LinearLayout.LayoutParams(0, WRAP, 1f).apply { leftMargin = dp(8) }
        )
        root.addView(row, lp(topDp = 14))
    }

    private fun renderAbout() {
        val about = card()
        root.addView(about, lp(topDp = 26))
        about.addView(tv("My Overlay  v1.2", 15f, C.TEXT, true))
        about.addView(tv("สร้างโดย kaew_kung", 13f, C.CYAN), lp(topDp = 2))
        about.addView(
            tv(
                "• เลเยอร์ที่เพิ่มทีหลังจะอยู่ด้านบน\n" +
                    "• ความทึบจริง = ความทึบเลเยอร์ × ความทึบรวม\n" +
                    "• ตำแหน่งแนวตั้งและแนวนอนแยกกัน\n" +
                    "• ลิงก์เว็บเป็นข้อมูลส่วนตัว อย่าแชร์ให้ใคร\n" +
                    "• บางยี่ห้อฆ่าแอปเบื้องหลัง ให้ตั้งแอปนี้เป็น \"ไม่จำกัดแบตเตอรี่\"",
                12f, C.SUB
            ),
            lp(topDp = 10)
        )
        about.addView(pill("ตั้งค่าแบตเตอรี่", C.CARD2) {
            try {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            } catch (e: Exception) {
                toast("เปิดหน้าตั้งค่าไม่ได้")
            }
        }, lp(topDp = 12))
    }

    private fun section(t: String): TextView = tv(t, 13f, C.SUB, true).apply {
        letterSpacing = 0.06f
        setPadding(dp(4), 0, 0, 0)
    }

    private fun layerRow(l: Layer): View {
        val card = card()
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val icon = when (l.kind) {
            Kind.WEB -> "🌐"
            Kind.IMAGE -> "🖼"
            Kind.TEXT -> "Aa"
        }
        top.addView(tv(icon, 20f, C.TEXT), LinearLayout.LayoutParams(dp(40), WRAP))
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(tv(l.name, 16f, C.TEXT, true))
        col.addView(tv(subtitle(l), 12f, C.SUB), lp(topDp = 1))
        top.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f))

        val sw = Switch(this).apply {
            isChecked = l.enabled
            val st = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
            thumbTintList = ColorStateList(st, intArrayOf(C.CYAN, C.SUB))
            trackTintList = ColorStateList(st, intArrayOf(0x6622D3EE, 0x44A39BC8))
            setOnCheckedChangeListener { _, v ->
                mutate(rerender = false) { list -> list.find { it.id == l.id }?.enabled = v }
            }
        }
        top.addView(sw)
        card.addView(top)

        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        actions.addView(
            pill("✎ แก้ไข", C.CARD2) { showEditor(l, l.kind) },
            LinearLayout.LayoutParams(0, WRAP, 1f)
        )
        actions.addView(
            pill("🗑 ลบ", C.CARD2, C.DANGER) { confirmDelete(l) },
            LinearLayout.LayoutParams(0, WRAP, 1f).apply { leftMargin = dp(8) }
        )
        card.addView(actions, lp(topDp = 12))
        return card
    }

    private fun subtitle(l: Layer): String = when (l.kind) {
        Kind.WEB -> "เว็บ • " + (try { Uri.parse(l.url).host } catch (e: Exception) { null } ?: "-")
        Kind.IMAGE -> "รูป / GIF"
        Kind.TEXT -> "ข้อความ • " + l.text.replace("\n", " ").take(24)
    }

    private fun confirmDelete(l: Layer) {
        AlertDialog.Builder(this, dialogTheme)
            .setTitle("ลบเลเยอร์นี้?")
            .setMessage("ลบแล้วกู้กลับไม่ได้")
            .setNegativeButton("ยกเลิก", null)
            .setPositiveButton("ลบ") { _, _ ->
                mutate { list ->
                    list.removeAll { it.id == l.id }
                    if (l.kind == Kind.IMAGE) releaseUri(l.uri)
                }
            }
            .show()
    }

    // ---------- เพิ่ม / แก้ไขเลเยอร์ ----------

    private fun defaultName(k: Kind) = when (k) {
        Kind.WEB -> "เว็บ"
        Kind.IMAGE -> "รูป"
        Kind.TEXT -> "ข้อความ"
    }

    private fun addLayer(kind: Kind) {
        if (layers.size >= MAX_LAYERS) {
            toast("เลเยอร์เต็มแล้ว (สูงสุด $MAX_LAYERS)")
            return
        }
        if (kind == Kind.IMAGE) pickImage("") else showEditor(null, kind)
    }

    private fun label(t: String): TextView = tv(t, 12f, C.SUB).apply { setPadding(dp(2), dp(14), 0, dp(4)) }

    private fun field(hint: String, value: String, input: Int = InputType.TYPE_CLASS_TEXT, multiline: Boolean = false): EditText =
        EditText(this).apply {
            setText(value)
            this.hint = hint
            setTextColor(C.TEXT)
            setHintTextColor(C.SUB)
            textSize = 15f
            background = roundBg(C.CARD2, dp(12).toFloat())
            setPadding(dp(14), dp(12), dp(14), dp(12))
            inputType = if (multiline) input or InputType.TYPE_TEXT_FLAG_MULTI_LINE else input
            if (multiline) {
                minLines = 3
                gravity = Gravity.TOP
            }
        }

    private fun showEditor(existing: Layer?, kind: Kind) {
        val form = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(4), dp(20), dp(8))
        }
        val nameF = field("ชื่อเลเยอร์", existing?.name ?: defaultName(kind))
        form.addView(label("ชื่อเลเยอร์"))
        form.addView(nameF)

        var urlF: EditText? = null
        var textF: EditText? = null
        var sizeF: EditText? = null
        var colorF: EditText? = null
        var dlgRef: AlertDialog? = null

        when (kind) {
            Kind.WEB -> {
                val u = field(
                    "https://...", existing?.url ?: "",
                    InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
                )
                urlF = u
                form.addView(label("ลิงก์เว็บ (https) • เป็นข้อมูลส่วนตัว"))
                form.addView(u)
            }
            Kind.TEXT -> {
                val t = field("พิมพ์ข้อความที่จะแสดง", existing?.text ?: "", multiline = true)
                val s = field("1–96", (existing?.textSize ?: 28).toString(), InputType.TYPE_CLASS_NUMBER)
                val c = field("#RRGGBB หรือ #AARRGGBB", existing?.textColor ?: "#FFFFFF")
                textF = t
                sizeF = s
                colorF = c
                form.addView(label("ข้อความ (1–2000 ตัวอักษร)"))
                form.addView(t)
                form.addView(label("ขนาดตัวอักษร (sp)"))
                form.addView(s)
                form.addView(label("สีข้อความ"))
                form.addView(c)
            }
            Kind.IMAGE -> {
                form.addView(pill("เปลี่ยนรูป / GIF", C.CARD2) {
                    dlgRef?.dismiss()
                    existing?.let { pickImage(it.id) }
                }, lp(topDp = 14))
            }
        }

        val opLabel = label("ความทึบเลเยอร์: ${existing?.opacity ?: 100}%")
        val seek = SeekBar(this).apply {
            max = 90
            progress = (existing?.opacity ?: 100) - 10
        }
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                opLabel.text = "ความทึบเลเยอร์: ${p + 10}%"
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        form.addView(opLabel)
        form.addView(seek)

        val dlg = AlertDialog.Builder(this, dialogTheme)
            .setTitle(if (existing == null) "เพิ่มเลเยอร์" else "แก้ไขเลเยอร์")
            .setView(ScrollView(this).apply { addView(form) })
            .setNegativeButton("ยกเลิก", null)
            .setPositiveButton("บันทึก", null)
            .create()
        dlgRef = dlg

        dlg.setOnShowListener {
            dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val name = nameF.text.toString().trim().ifEmpty { defaultName(kind) }.take(30)
                val opacity = seek.progress + 10
                var url = ""
                var text = ""
                var size = 28
                var color = "#FFFFFF"

                when (kind) {
                    Kind.WEB -> {
                        url = urlF?.text?.toString()?.trim().orEmpty()
                        val host = try { Uri.parse(url).host } catch (e: Exception) { null }
                        if (!url.startsWith("https://") || host.isNullOrEmpty() || url.length > 2000) {
                            toast("ลิงก์ต้องขึ้นต้น https:// และถูกต้อง")
                            return@setOnClickListener
                        }
                    }
                    Kind.TEXT -> {
                        text = textF?.text?.toString().orEmpty()
                        if (text.isBlank() || text.length > 2000) {
                            toast("ใส่ข้อความ 1–2000 ตัวอักษร")
                            return@setOnClickListener
                        }
                        val s = sizeF?.text?.toString()?.trim()?.toIntOrNull()
                        if (s == null || s !in 1..96) {
                            toast("ขนาดต้องอยู่ระหว่าง 1 ถึง 96 sp")
                            return@setOnClickListener
                        }
                        size = s
                        color = colorF?.text?.toString()?.trim().orEmpty()
                        try {
                            Color.parseColor(color)
                        } catch (e: Exception) {
                            toast("สีต้องเป็น #RRGGBB หรือ #AARRGGBB")
                            return@setOnClickListener
                        }
                    }
                    Kind.IMAGE -> {}
                }

                mutate { list ->
                    if (existing == null) {
                        if (list.size < MAX_LAYERS) {
                            val n = newLayer(kind, name)
                            n.url = url
                            n.text = text
                            n.textSize = size
                            n.textColor = color
                            n.opacity = opacity
                            list.add(n)
                        }
                    } else {
                        list.find { it.id == existing.id }?.let {
                            it.name = name
                            it.opacity = opacity
                            if (kind == Kind.WEB) it.url = url
                            if (kind == Kind.TEXT) {
                                it.text = text
                                it.textSize = size
                                it.textColor = color
                            }
                        }
                    }
                }
                dlg.dismiss()
            }
        }
        dlg.show()
    }

    // ---------- เลือกรูป / GIF ----------

    @Suppress("DEPRECATION")
    private fun pickImage(targetId: String) {
        pendingImageId = targetId
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
            .addCategory(Intent.CATEGORY_OPENABLE)
            .setType("image/*")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        try {
            startActivityForResult(i, reqImage)
        } catch (e: ActivityNotFoundException) {
            toast("ไม่พบแอปสำหรับเลือกรูป")
        }
    }

    private fun releaseUri(uri: String) {
        try {
            contentResolver.releasePersistableUriPermission(Uri.parse(uri), Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (e: Exception) {
        }
    }

    private fun queryMeta(uri: Uri): Pair<String?, Long> {
        var name: String? = null
        var size = -1L
        try {
            contentResolver.query(uri, null, null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    val si = c.getColumnIndex(OpenableColumns.SIZE)
                    if (ni >= 0) name = c.getString(ni)
                    if (si >= 0 && !c.isNull(si)) size = c.getLong(si)
                }
            }
        } catch (e: Exception) {
        }
        return Pair(name, size)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != reqImage) return
        val target = pendingImageId
        pendingImageId = null
        val uri = data?.data
        if (resultCode != RESULT_OK || uri == null || target == null) return

        val mime = contentResolver.getType(uri) ?: ""
        if (!mime.startsWith("image/")) {
            toast("ไฟล์นี้ไม่ใช่รูปภาพที่รองรับ")
            return
        }
        val (fileName, size) = queryMeta(uri)
        if (size > 20L * 1024 * 1024) {
            toast("ไฟล์ใหญ่เกิน 20 MB เลือกรูป/GIF ที่เล็กลง")
            return
        }
        try {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (e: Exception) {
            toast("ไฟล์นี้ให้สิทธิ์อ่านถาวรไม่ได้ กรุณาเลือกจากแอป Files")
            return
        }

        if (target.isEmpty()) {
            mutate { list ->
                if (list.size < MAX_LAYERS) {
                    val n = newLayer(Kind.IMAGE, (fileName ?: "รูป").take(30))
                    n.uri = uri.toString()
                    list.add(n)
                }
            }
            toast("เพิ่มรูปแล้ว • กด ✎ แก้ไขตำแหน่งเพื่อจัดวาง")
        } else {
            mutate { list ->
                list.find { it.id == target }?.let {
                    releaseUri(it.uri)
                    it.uri = uri.toString()
                }
            }
            toast("เปลี่ยนรูปแล้ว")
        }
    }
}
